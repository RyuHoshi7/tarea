String? validateTaskTitle(String? value) {
  if (value == null || value.trim().isEmpty) return 'Escribe un título';
  if (value.trim().length < 3) return 'Usa al menos 3 caracteres';
  return null;
}
