import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/task.dart';

abstract class TaskRepository {
  Stream<List<Task>> watchTasks();
  Future<void> addTask({required String title, required String description});
  Future<void> updateTask(Task task);
  Future<void> deleteTask(String id);
}

class FirestoreTaskRepository implements TaskRepository {
  FirestoreTaskRepository({FirebaseFirestore? firestore})
      : _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _firestore;
  CollectionReference<Map<String, dynamic>> get _tasks =>
      _firestore.collection('tasks');

  @override
  Stream<List<Task>> watchTasks() => _tasks
      .orderBy('createdAt', descending: true)
      .snapshots()
      .map((snapshot) => snapshot.docs
          .map((doc) => Task.fromMap(doc.id, doc.data()))
          .toList());

  @override
  Future<void> addTask({
    required String title,
    required String description,
  }) async {
    await _tasks.add({
      'title': title.trim(),
      'description': description.trim(),
      'isDone': false,
      'createdAt': DateTime.now().toIso8601String(),
    });
  }

  @override
  Future<void> updateTask(Task task) async {
    await _tasks.doc(task.id).update(task.toMap());
  }

  @override
  Future<void> deleteTask(String id) async {
    await _tasks.doc(id).delete();
  }
}
