# Notificaciones FCM

No aplica a esta versión del proyecto. FCM no está incluido en la declaración de alcance, por lo tanto no se ejecutan CP-14 a CP-17 ni se presentan evidencias de notificaciones.
