# Evidencias

La imagen `capturas-aplicacion/referencia-interfaz.png` muestra la propuesta visual de la aplicación. Para completar las evidencias de ejecución exigidas, sustituya o complemente esta referencia con capturas reales del emulador/dispositivo:

- `capturas-aplicacion/`: lista, formulario, edición y eliminación.
- `firebase/`: colección `tasks` y documentos creados/actualizados/eliminados.
- `notificaciones-fcm/`: no aplica; FCM está fuera del alcance declarado.
- `pruebas-y-analisis/`: terminal con `flutter test` y `flutter analyze`.

La referencia visual no sustituye capturas de ejecución real ni demuestra por sí sola una conexión con Firebase.
