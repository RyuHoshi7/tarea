# 01. Declaración de alcance

**Proyecto:** Gestión de tareas  
**Servicio principal:** Cloud Firestore  
**Plataforma objetivo:** Android  
**Rama:** `semana16-integracion`

| Módulo / servicio | ¿Aplica? | Observación |
|---|---|---|
| Autenticación | No | La versión de esta práctica no incorpora cuentas de usuario. |
| Base de datos Firestore | Sí | Colección `tasks`; altas, lectura en tiempo real, actualización y eliminación. |
| Almacenamiento Storage | No | No se adjuntan imágenes ni archivos a las tareas. |
| Notificaciones FCM | No | No forma parte del alcance funcional de esta versión. |
| API REST externa | No | La persistencia se realiza directamente con Firestore. |
| Otros | No | No se integran Analytics, Crashlytics ni Remote Config. |

**Justificación:** Se delimita el alcance a Firestore para concentrar la validación en los flujos CRUD y la presentación reactiva de datos. Los casos de Auth, Storage y FCM quedan fuera del alcance y no deben reportarse como ejecutados.
