# 03. Plantilla de pruebas

**Instrucción:** completar la columna “Resultado obtenido”, fecha, dispositivo y evidencia después de ejecutar cada caso. No marcar como Aprobado sin ejecución y evidencia reales.

| ID | Módulo | Descripción / entrada | Resultado esperado | Resultado obtenido / estado |
|---|---|---|---|---|
| CP-01 | Arranque | Abrir la app | Lista visible sin excepción | Pendiente de ejecución |
| CP-02 | Navegación | Pulsar Nueva tarea | Abre formulario | Pendiente de ejecución |
| CP-03 | Navegación | Volver desde formulario | Regresa a lista | Pendiente de ejecución |
| CP-04 | Validación | Guardar título vacío | Mensaje “Escribe un título”; sin escritura | Automatizado en test; repetir en dispositivo |
| CP-05 | Validación | Título “ab” | Mensaje de mínimo 3 caracteres | Automatizado en unit test; repetir en dispositivo |
| CP-06 | Datos | Crear “Comprar materiales” | Documento aparece en lista | Pendiente de ejecución con Firebase |
| CP-07 | Datos | Abrir y editar descripción | Cambio reflejado en lista y Firestore | Pendiente de ejecución con Firebase |
| CP-08 | Datos | Marcar checkbox | Estado completado actualizado | Pendiente de ejecución con Firebase |
| CP-09 | Datos | Eliminar tarea | Documento y elemento desaparecen | Pendiente de ejecución con Firebase |
| CP-10 | Persistencia | Cerrar y reabrir app | Tareas conservadas | Pendiente de ejecución con Firebase |
| CP-11 | Estados | Firestore sin documentos | Mensaje “No hay tareas todavía” | Pendiente de ejecución |
| CP-12 | Errores | Simular pérdida de conexión | Mensaje controlado, sin cierre | Pendiente de ejecución |

**Resumen:** 12 casos definidos. Los resultados reales deben completarse en emulador/dispositivo conectado a Firebase. Las pruebas automatizadas incluidas cubren validación y formulario mediante repositorio falso; no sustituyen la prueba real de integración con Firestore.
