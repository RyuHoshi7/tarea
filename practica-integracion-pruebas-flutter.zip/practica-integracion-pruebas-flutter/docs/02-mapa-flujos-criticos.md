# 02. Mapa de flujos críticos

1. El usuario puede abrir la aplicación y visualizar la lista de tareas.
2. El usuario puede crear una tarea con título válido y descripción opcional.
3. El usuario puede seleccionar una tarea, modificar sus datos y guardar los cambios.
4. El usuario puede marcar una tarea como completada y observar el cambio en la lista.
5. El usuario puede eliminar una tarea y confirmar que deja de aparecer en la lista.

**Flujo negativo transversal:** el usuario intenta guardar un formulario vacío o con un título de menos de tres caracteres; la aplicación muestra validación y no escribe en Firestore.
