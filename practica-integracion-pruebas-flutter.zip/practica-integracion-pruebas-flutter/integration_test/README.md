# Pruebas de integración

La integración real con Firebase requiere proyecto y dispositivo/emulador configurados. Para evitar escribir en una base de datos real por accidente, esta carpeta contiene el procedimiento y no ejecuta operaciones remotas automáticamente.

Flujo recomendado: iniciar app → crear tarea de prueba → verificar documento en `tasks` → editar → marcar completada → eliminar → verificar ausencia.
