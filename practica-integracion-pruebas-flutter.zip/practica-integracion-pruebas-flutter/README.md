# Práctica de Integración y Pruebas Flutter – Gestión de tareas

Aplicación académica Flutter para crear, consultar, editar, completar y eliminar tareas mediante Cloud Firestore.

## Requisitos
- Flutter SDK estable y Dart compatible con `pubspec.yaml`.
- Android Studio o VS Code.
- Proyecto Firebase con Cloud Firestore habilitado.
- Emulador o dispositivo Android.

## Configuración Firebase
1. Cree un proyecto en Firebase Console.
2. Registre la aplicación Android con el `applicationId` de su proyecto Flutter.
3. Configure FlutterFire CLI (`dart pub global activate flutterfire_cli` y `flutterfire configure`).
4. Ejecute `flutter pub get`.
5. Verifique que `Firebase.initializeApp()` tenga la configuración generada para su plataforma.
6. Cree la colección `tasks` o permita su creación al insertar el primer documento.
7. Configure reglas seguras antes de publicar. No use reglas abiertas en producción.

> No se incluye `google-services.json`, archivo de opciones Firebase ni credenciales. Cada integrante debe configurar su propio proyecto Firebase.

## Ejecución
```bash
flutter pub get
flutter run
```

## Validación
```bash
flutter analyze
flutter test
```

## Funciones
- Listado en tiempo real con StreamBuilder.
- Alta y edición de tareas.
- Marcado de tareas completadas.
- Eliminación de tareas.
- Validación de título obligatorio (mínimo 3 caracteres).
- Mensajes de error controlados.

## Rama de trabajo sugerida
```bash
git checkout -b semana16-integracion
```

## Estado de evidencias
Los archivos de `docs/` incluyen la documentación y formatos de registro. Las imágenes de referencia de interfaz sirven para orientar las capturas que deben obtenerse al ejecutar la aplicación real. Registre los resultados reales de `flutter analyze`, `flutter test`, Firebase Console y el dispositivo antes de entregar.
